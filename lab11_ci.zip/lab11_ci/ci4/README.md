# TUGAS Lab6 PHP Framework (Codeigniter) Pemograman Web 2

**_Nama : Fadli Ramadan_** <br/>
**_NIM : 312110538_** <br/>
**_Kelas : TI.21.A3_** <br/>